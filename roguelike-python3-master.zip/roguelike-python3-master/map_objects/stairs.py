class Stairs:
    """
    Stairs component for entity class.
    """
    def __init__(self, floor):
        self.floor = floor
